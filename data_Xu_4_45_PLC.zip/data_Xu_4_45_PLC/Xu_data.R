### Please run model first ###


### Xu_4_45_data ###
Xu_data = read.csv("Xu_data.csv")

# tiff("P2F2_Fig_2_Xu.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

par(mar=c(5,6,4,5)+.1)
plot(Xu_data$X1,Xu_data$PI45P2,type='p',col='black',pch=19,
	xlim=c(-20,160),ylim=c(0,2),
	main='PLC activation',
	xlab='Time (s)',ylab='fold change',
	cex.main=3, cex.lab=3, cex.axis=2
	)
points(Xu_data$X1[2],Xu_data$PI45P2[2],type='p',col='red',pch=19)
segments(x0=Xu_data$X1,y0=Xu_data$PI45P2_DW,y1=Xu_data$PI45P2_UP,col='black')
segments(x0=Xu_data$X1[2],y0=Xu_data$PI45P2_DW[2],y1=Xu_data$PI45P2_UP[2],col='red')
points(Xu_data$X2,Xu_data$PI4P,type='p',col='purple',pch=17)
segments(x0=Xu_data$X2,y0=Xu_data$PI4P_DW,y1=Xu_data$PI4P_UP,col='purple')
legend(x=-20,y=2,legend=c('PI45P2','PI4P'),pch=c(19,17),col=c('black','purple'),text.col=c('black','purple'),bty = "n",cex=2)
legend(x=25,y=2,legend=c('Model PI45P2','Model PI4P'),lty=1,lwd=5,col=c('black','purple'),text.col=c('black','purple'),bty = "n",cex=2)



# Insert the number of time units that the simulation will run
tmax=13
# Insert the step of the simulation
tstep=1/600
t=seq(0,tmax+1,tstep) 	# time

# Finaly remove the # form the front of all the next code lines
# On the first column put the time of the perturbation
ptime=c(0,10,max(t));
# On the second column put the variables to be altered. (ex: 'X')
pvar=c('novar','PLC','novar')
# On the third the new value for the variable.
pval=c(NA,
	parameters[names(parameters)=='PLC']*13,
	NA)
perturbations=data.frame(time=ptime,var=pvar,val=pval)
perturbations


out = Cruncher(state,t,equations,parameters,perturbations)						# no perturbations			# with perturbations
# edit(out)
# View(out)

# normalized graphs
stst=out[300,]						# getting steady state at time 500
out_n=cbind(time=out[1],out[,2:ncol(out)])
tail(out_n)
out_norm=out[,1]						# creating matrix out_norm to store the normalized information
for (i in 2:ncol(out))
	{
	newc=c(out_n[,i]/as.numeric(stst[i]))	# normalizing to steady state got at time 500
	out_norm=cbind(out_norm,newc)			# storing normalized information
	}
colnames(out_norm)=colnames(out)
head(out_norm)
# View(out_norm)

points((out_norm[4790:5000,1]-10)*60,out_norm[4790:5000,7],type='l',col='black',lwd='5')
points((out_norm[4790:5000,1]-10)*60,out_norm[4790:5000,4],type='l',col='purple',lwd='5')


# stoping the simulation and starting again with a new PLC value
state_1=out[5000,2:14]
parameters_l=parameters
names(state_1)=names(state)
parameters_l[names(parameters_l)=='PLC']=5
out_1 = Cruncher(state_1,t,equations,parameters_l)						# no perturbations			# with perturbations


# normalized graphs
stst1=out[300,]						# getting steady state at time 500
out_n1=cbind(time=out_1[1],out_1[,2:ncol(out_1)])
tail(out_n1)
out_norm1=out_1[,1]						# creating matrix out_norm to store the normalized information
for (i in 2:ncol(out_1))
	{
	newc1=c(out_n1[,i]/as.numeric(stst1[i]))	# normalizing to steady state got at time 500
	out_norm1=cbind(out_norm1,newc1)			# storing normalized information
	}
colnames(out_norm1)=colnames(out_1)

#points(out_norm1[,1]*60+20,out_norm1[,7],col='green')
points(out_norm1[,1]*60+20,type='l',out_norm1[,7],col='black',lwd='5')
#points(out_norm1[,1]*60+20,out_norm1[,4],col='green')
points(out_norm1[,1]*60+20,type='l',out_norm1[,4],col='purple',lwd='5')

# dev.off()




