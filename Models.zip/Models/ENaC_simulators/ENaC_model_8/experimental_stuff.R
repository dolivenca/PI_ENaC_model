#########################
#				#
#	experimental 	#
#				#
#########################


#install.packages("deSolve")
library(deSolve)	#library for solve diferential equations
#citation("deSolve")



run_until_STST = function(state,equations,parameters)
	{
	# Insert the number of time units that the simulation will run
	tmax_1=1000
	# Insert the step of the simulation
	tstep=1
	t_1=seq(0,tmax_1+1,tstep) 	# time

	out_1 = Cruncher(state,t_1,equations,parameters)
	out_store = out_1
	token = 1
	while (token>0)
		{
		token = 0
		for (i in 1:length(state))
			{
			if (abs(max(out_1[(tmax_1-100):tmax_1,i+1]) - min(out_1[(tmax_1-500):(tmax_1-400),i+1]))>1e-7)
				{
				if ( max(out_1[(tmax_1-100):tmax_1,i+1]) == max(out_1[(tmax_1-500):(tmax_1-400),i+1]) & min(out_1[(tmax_1-100):tmax_1,i+1])==min(out_1[(tmax_1-500):(tmax_1-400),i+1]) )
					{
					print('Possibly oscillating')
					} else { token = token + 1 } 
				}
			}
		if (token>0)
			{
			state_1 = out_1[tmax_1,2:(length(state)+1)]
			names(state_1) = names(state)
			tmax_1 = tmax_1 * 2
			t_1=seq(0,tmax_1+1,tstep) 	# time
			out_1 = Cruncher(state_1,t_1,equations,parameters)
			out_store = rbind(out_store,out_1)
			} else { out_store }
		}
	out_store
	}	

run_until_STST(state,equations,parameters)



