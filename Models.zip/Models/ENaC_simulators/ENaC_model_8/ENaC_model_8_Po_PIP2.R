##################
### ENaC Model ###
##################


rm(list=ls())	#clean memory
graphics.off() 	#close plot windows

library(deSolve)	#library for solve diferential equations
#citation("deSolve")

# Insert the number of time units that the simulation will run
tmax=100000
# Insert the step of the simulation
tstep=1
t=seq(0,tmax+1,tstep) 	# time

ENaC_op = function(PIP2)
	{.02+.8/(1+181429*exp(-.00112*PIP2))}
ENaC_op(10000)


# Inicial states for variables
# insert, in the parentesis, the inicial value of the dependent variables (ex: X=2) 
state=c(
	ENaC = 35.00237,
	ASL = 7.000844
	) 

# CF steady state 
#state=c(
#	ENaC = 80,
#	ASL = 4.00098-2.226505e-07-4.52971e-14
#	) 

# insert, in the parentecis, the parameters and independent variables and their values (ex: const=5, rate=2). 
# If no parameters and independent variables just put a zero.
parameters=c(
		PI45P2 = 10000,
		SPLUNC1 = 7890,

		gamma__ENaC = log(2)/40,
		gamma_ENaC_SPLUNC1 = 15*log(2)/4208,
		gamma_ENaC_ = 25*log(2)/8,

		gamma_ASL_ENaC = 0.0003922396,
		gamma_CFTR_ASL = 0.0177052536
		)   
parameters=c(
		parameters,
		gamma__ASL = (105)*as.numeric(parameters[names(parameters)=='gamma_ASL_ENaC'])+(4/3)*as.numeric(parameters[names(parameters)=='gamma_CFTR_ASL']),
		gamma_ASL_ = (25/4)*as.numeric(parameters[names(parameters)=='gamma_ASL_ENaC'])+(1/3)*as.numeric(parameters[names(parameters)=='gamma_CFTR_ASL'])	
		)

equations=function(t,state,parameters) 	# function containing the diferential equations
	{with(as.list(c(state,parameters)),
		{
		#rate of change (velocities of the variables concentration changes), the actual diferencial equations
		# insert the diferentical equations (ex: dX=const*X^rate or dX=5*X^2)

		V__ENaC = gamma__ENaC
		V_ENaC_SPLUNC1 = gamma_ENaC_SPLUNC1 * ENaC * (SPLUNC1/ASL) * PI45P2^(-1) 
		V_ENaC_ = gamma_ENaC_ * ENaC * PI45P2^(-1)

		V__ASL = gamma__ASL
		V_CFTR_ASL = gamma_CFTR_ASL
		V_ASL_ENaC = gamma_ASL_ENaC * ASL * (ENaC * ENaC_op(PI45P2))
		V_ASL_ = gamma_ASL_ * ASL

		dENaC = V__ENaC - V_ENaC_SPLUNC1 - V_ENaC_ 
		dASL = V__ASL + V_CFTR_ASL - V_ASL_ENaC - V_ASL_
		
		# return the rate of change 
		# insert, in the parentecis, the variables that you want to store the values (ex:dX)
		list(dy=	c(dENaC,dASL),
				count=c(V__ENaC,V_ENaC_SPLUNC1,V_ENaC_,
					V__ASL,V_CFTR_ASL,V_ASL_ENaC,V_ASL_	
					   )
			)
		})
	}

perturbations=cbind(c('NA','NA'),c('NA','NA'),c('NA','NA'))	# initiation of perturbations matrix, if unaltered it will do no perturbations



##################################### Perturb ####################################
#ptime=c(0,20000,20003,80000,80003,max(t));
#pvar=c('novar','SPLUNC1','gamma_CFTR_ASL','SPLUNC1','gamma_CFTR_ASL','novar')
#pval=c(NA,0,0,parameters[names(parameters)=='SPLUNC1'],parameters[names(parameters)=='gamma_CFTR_ASL'],NA)
#perturbations=data.frame(time=ptime,var=pvar,val=pval)
#perturbations

#ptime=c(0,10000,20000,30000,30003,50000,60000,80000,80003,max(t));
#pvar=c('novar','PI45P2','PI45P2','SPLUNC1','gamma_CFTR_ASL','PI45P2','PI45P2','SPLUNC1','gamma_CFTR_ASL','novar')
#pval=c(NA,5000,10000,0,0,5000,10000,parameters[names(parameters)=='SPLUNC1'],parameters[names(parameters)=='gamma_CFTR_ASL'],NA)
#perturbations=data.frame(time=ptime,var=pvar,val=pval)
#perturbations



################################## Cruncher function - ode integrator that deals with perturbations ###############################
Cruncher = function (state,t,equations,parameters,perturbations=cbind(c('NA','NA'),c('NA','NA'),c('NA','NA')))
	{

	# running the ode solver
	out_test=NA #cleanning out_MC vector

	# initializating the matrix out1 and out, necessary for the cycle
	out1=rbind(rep(0,1,length(state)+1),c(t=0,state))
	out_test=matrix()

	if (perturbations[1,1]=='NA') # if no perturbations an ordinary ODE is run
		{out_test <- ode(y = state, times = t, func = equations, parms=parameters)}

	if (perturbations[1,1]!='NA') # if there are perturbations, then go to the for cycle
		{
		if (tmax<max(perturbations[1:(nrow(perturbations)-1),1])) {cat("Time error: Last perturbation later than tmax.Please alter tmax or perturbation time.", "\n")}
		for (i in 1:(nrow(perturbations)-1)) # the number of perturbations is nrow(perturbations)-1 because the first line on the perturbations matrix is just to permit the inicial values to be used
			{
			t=seq(max(0,tail(out1[,1],1)+1),perturbations[i+1,1]-1,tstep)  	# set the time intervals #?#
	
			state=out1[nrow(out1),(2:(length(state)+1))]			# retrive the last values of the variables
			for (j in 1:length(state)) 						# check for variables perturbations
				{
				if (names(state)[j]==perturbations[i,2])			# if a perturbation is in a variable this will alter the variable value in the state vector
					{
					state[j]=perturbations[i,3]
					}
				}
			for (k in 1:length(parameters)) 						# check for variables perturbations
				{
				if (names(parameters)[k]==perturbations[i,2])			# if a perturbation is in a variable this will alter the variable value in the state vector
					{
					parameters[k]=perturbations[i,3]
					}
				}

			out1 <- ode(y = state, times = t, func = equations,parms=parameters)	# good and old ode
			if (is.na(out_test[1,1])) {out_test=out1} else {out_test=rbind(out_test,out1)} 			# store the values of the last interval	
			}
		names(out_test)[1]='time'
		}
	out_test
	}

# out_test = Cruncher(state,t,equations,parameters)						# no perturbations
# perturbations1 = Perturb(parameters)
# out_test = Cruncher(state,t,equations,parameters,perturbations)			# with perturbations
# edit(out_test)



out = Cruncher(state,t,equations,parameters,perturbations)
# edit(out)
# View(out)

str(out)
varnames=c('Time (s)','ENaC','ASL') 
varcolors=c('gray','darkblue','cyan')
#  cbind(1:length(varnames),varnames,varcolors)

# naming fluxes in out
flux_names=c(
		'V__ENaC','V_ENaC_SPLUNC1','V_ENaC_',
		'V__ASL','V_CFTR_ASL','V_ASL_ENaC','V_ASL_'
		)
colnames(out)[(length(state)+2):dim(out)[2]]=flux_names

# cbind(1:length(parameters),parameters)
# cbind(21:(20+length(flux_names)),flux_names)

# time plot
par(mfrow=c(2,1))
for (i in c(2:3)) 
	{
	plot(out[,1],out[,i],type='l',col=varcolors[i])
	text(tmax,out[tmax-1,i],varnames[i],col=varcolors[i])
	}
par(mfrow=c(1,1))
           
# list (primitive)
(head(out,3))
(tail(out,3))



library(beepr)
beep(sound=1)













### ASL acording to SPLUNC1 concentrations ###	OK

# getwd()
# setwd("F:/Doc/P2F1_V11_New_Pars/P2F1_scripts_Choi_2")

# tiff("P2_SPLUNC1_2.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

# Data
Tarran_ASL_SPLUNC1_2 = read.csv("Tarran_ASL_SPLUNC1_data_2.csv")
par(mfrow=c(1,1),mar=c(5,6,4,1)+.1)
plot(Tarran_ASL_SPLUNC1_2$X,Tarran_ASL_SPLUNC1_2$SPLUNC1,
	xlim = c(-3,5),ylim = c(6,14),pch = 19,cex = 1.5,col = 'black',
	xlab = expression(paste('log'[10],'[SPLUNC1] (',mu,'M)')), 
	ylab = expression(paste('ASL thickness (',mu,'m)')),
	cex.lab=2,cex.axis=2,cex.main=3
	)
segments(x0=Tarran_ASL_SPLUNC1_2$X,y0=Tarran_ASL_SPLUNC1_2$SPLUNC1_DW,
	x1=Tarran_ASL_SPLUNC1_2$X,y1=Tarran_ASL_SPLUNC1_2$SPLUNC1_UP,
	col='black',lwd=3) 
legend(
	'topleft',legend=c('data','model 4H','model STST'),
	col=c('black','blue','cyan'),bty='n',cex=2,
	lwd=c(5,5,5)
	)  

# Model
tmax=5000; tstep=1; t=seq(0,tmax+1,tstep) 	# time
state_ASL_SPLUNC1 = state
state_ASL_SPLUNC1[2]=25
parameters_ASL_SPLUNC1=parameters
aux1=vector()
aux2=vector()
aux3=vector()
for (i in seq(-3,5,.1)) 
	{
	parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='SPLUNC1']= 10^(i) * 6.02214076e2 * 25
	out = Cruncher(state_ASL_SPLUNC1,t,equations,parameters_ASL_SPLUNC1)
	points(i,out[240,3],cex=.5,col='blue')
	aux1=c(aux1,out[4999,3])
	aux3=c(aux3,out[240,3])
	aux2=c(aux2,out[4999,2])	
	}
points(seq(-3,5,.1),aux1,type='l',col='cyan',lwd=5)
points(seq(-3,5,.1),aux3,type='l',col='blue',lwd=5)

# dev.off()





###############################
#					#
#	Optimization		#
#					#
###############################

# Data

# setwd("C:/Users/dolivenca/OneDrive/BIOSYS/Papers/BIOISI/phosphoinositides/P2/Fork/P2F1_ENaC/P2F1_V11_New_Pars/P2F1_Scripts")
# setwd("F:/Doc/P2F1_V11_New_Pars/P2F1_scripts_Choi_2")

Tarran_ASL_SPLUNC1_2 = read.csv("Tarran_ASL_SPLUNC1_data_2.csv")
data_optim = rbind(Tarran_ASL_SPLUNC1_2, Tarran_ASL_SPLUNC1_2[7,],Tarran_ASL_SPLUNC1_2[7,], Tarran_ASL_SPLUNC1_2[7,])
par(mfrow=c(1,1),mar=c(5,6,4,1)+.1)
plot(Tarran_ASL_SPLUNC1_2$X,Tarran_ASL_SPLUNC1_2$SPLUNC1,
	xlim = c(-3,5),ylim = c(6,14),pch = 19,cex = 1.5,col = 'black',
	xlab = expression(paste('log'[10],'[SPLUNC1] (',mu,'M)')), 
	ylab = expression(paste('ASL thickness (',mu,'m)')),
	cex.lab=2,cex.axis=2,cex.main=3
	)
segments(x0=Tarran_ASL_SPLUNC1_2$X,y0=Tarran_ASL_SPLUNC1_2$SPLUNC1_DW,
	x1=Tarran_ASL_SPLUNC1_2$X,y1=Tarran_ASL_SPLUNC1_2$SPLUNC1_UP,
	col='black',lwd=3) 
legend(
	'topleft',legend=c('data','model 4H','model STST'),
	col=c('black','blue','cyan'),bty='n',cex=2,
	lwd=c(5,5,5)
	)  



# Optim

tmax=5000
tstep=1
t=seq(0,tmax+1,tstep)

perturbations=cbind(c('NA','NA'),c('NA','NA'),c('NA','NA'))	# initiation of perturbations matrix, if unaltered it will do no perturbations
pars2find = c(
		0.00037, 1.715000e-02
		)
pars2find_names = c(
			'gamma_ASL_ENaC',
			'gamma_CFTR_ASL'
			)
cbind(pars2find_names, pars2find)

error_function = function (pars2find)
	{
	if (sum(pars2find>0)==length(pars2find))
		{
		pars_optim = parameters
		pars_optim[names(pars_optim)=='gamma_ASL_ENaC'] = pars2find[1]
		pars_optim[names(pars_optim)=='gamma_CFTR_ASL'] = pars2find[2]	

		pars_optim[names(pars_optim)=='gamma__ASL'] = 105*pars2find[1] + (4/3)*pars2find[2]
		pars_optim[names(pars_optim)=='gamma_ASL_'] = (25/4)*pars2find[1] + (1/3)*pars2find[2] 

		tmax=5000; tstep=1; t=seq(0,tmax+1,tstep) 	# time

		state_optim = state
		state_optim[2]=25


		aux=vector()
		for (i in c(-3,-2,-1,0,1,1.38,2,3,4,5)) 
			{
			pars_optim[names(pars_optim)=='SPLUNC1']= 10^(i) * 6.02214076e2 * 25
			out_optim = Cruncher(state_optim,t,equations,pars_optim)
			aux = c(aux,out_optim[240,3])
			}
		points(c(-3,-2,-1,0,1,1.38,2,3,4,5),aux,col='blue',cex=3)
		count1=0
		for (ii in 1:length(aux))
			{
			if (aux[ii]<=data_optim[ii,2] | aux[ii]>=data_optim[ii,4])
				{
				count1=count1 + 10
				}
			}		
		sum(abs(aux - data_optim$SPLUNC1)) + count1
		} else {10^10}
	}
error_function(pars2find)

# pars2find=op$par

op=optim(
	par = pars2find,
	method = "Nelder-Mead",
#	lower = 0, upper = 10,
	fn = error_function,
      )

	control = list(
			maxit = 5000, 
			trace = TRUE,
                  REPORT = 10,
			fnscale = 20.8,
			parscale = c(.0002)
			)
	) 
	
op
names(op)	

# op$par * pars2find

#	lower = lbound, upper = ubound,
# c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent"),

library(beepr)
beep(sound=1)

# Best pars
# 0.0003922396 0.0177052536

# Model
tmax=5000; tstep=1; t=seq(0,tmax+1,tstep) 	# time
state_ASL_SPLUNC1 = state
state_ASL_SPLUNC1[2]=25
parameters_ASL_SPLUNC1=parameters

parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='gamma_ASL_ENaC'] = op$par[1]
parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='gamma_CFTR_ASL'] = op$par[2]
parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='gamma__ASL'] = (105)*op$par[1]+(4/3)*op$par[2]
parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='gamma_ASL_'] = (25/4)*op$par[1]+(1/3)*op$par[2]	

aux1=vector()
aux2=vector()
aux3=vector()
for (i in seq(-3,5,.1)) 
	{
	parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='SPLUNC1']= 10^(i) * 6.02214076e2 * 25
	out = Cruncher(state_ASL_SPLUNC1,t,equations,parameters_ASL_SPLUNC1)
	points(i,out[240,3],cex=.5,col='blue')
	aux1=c(aux1,out[4999,3])
	aux3=c(aux3,out[240,3])
	aux2=c(aux2,out[4999,2])	
	}


points(seq(-3,5,.1),aux1,type='l',col='cyan',lwd=5)
points(seq(-3,5,.1),aux3,type='l',col='blue',lwd=5)







###############################
#					#
#		FIG S3 A		#
#		Model fitting	#
#		ASL_WT		#
#					#
###############################

Tarran1 = read.csv("Tarran_ASL_data1.csv")
Tarran2 = read.csv("Tarran_ASL_data2.csv")
Tarran3 = read.csv("Tarran_ASL_data3.csv")
Button_WT = read.csv("Button_ASL_WT_data.csv") 
Sandefur = read.csv("Sandefur_ASL_data.csv")

tmax=3000
tstep=1
t=seq(0,tmax+1,tstep) 	# time

# tiff("P2FS3A_HL.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

# data
par(mar=c(5,6,4,1)+.1)
plot(Tarran1$X*60,Tarran1$Y,
	xlim=c(0,3000),ylim=c(0,40),
	main='HL ASL', xlab='Time (min)',ylab='ASL thickness',
	cex.lab=3,cex.axis=2,cex.main=3,	
	pch=16,cex=3,col='blue'
	)
segments(x0=Tarran1$X*60,y0=Tarran1$Y_lower,x1=Tarran1$X*60,y1=Tarran1$Y_upper,col='blue',lwd=3) 
points(Tarran2$X*60,Tarran2$Y_control,pch=17,cex=3,col='black') 
points(Tarran3$X*60,Tarran3$Y_WT,pch=18,cex=3,col='red') 
points(Button_WT$X*60,Button_WT$Y,pch=15,cex=3,col='green')
segments(x0=Button_WT$X*60,y0=Button_WT$Y_lower,x1=Button_WT$X*60,y1=Button_WT$Y_upper,col='green',lwd=3) 
points(Sandefur$X*60,Sandefur$Y_WT,pch=16,cex=3,col='violet')
segments(x0=Sandefur$X*60,y0=Sandefur$Y_WT_DW,x1=Sandefur$X*60,y1=Sandefur$Y_WT_UP,col='violet',lwd=3) 

abline(h=7,col='orange')

legend (x = 'topright', 							# position
	legend = c('Caballero et al. data','Hobbs et al. data','Tarran et al. data','Button et al. data','Sandefur et al. data'),	# legend's text  
	text.col =  c('blue','black','red','green','violet'),
	pch=c(16,17,18,15,16),							# legend's objects point character 
	col = c('blue','black','red','green','violet'),
	cex =3,									# font size for legend
	bty = "n"									# no legend box
	)

plot_colors = c('blue','black','red','green','violet')
WT_ASL_starts = c(22.589074,29.958746,24.28082,31.169982,24.986577)
for (i in 1:5)
	{
	state_WT=c(
		ENaC = 35,
		ASL = WT_ASL_starts[i]
		) 
	out = Cruncher(state_WT,t,equations,parameters)
	points(out[,1],out[,3],type='l',col=plot_colors[i],lwd=3)		
	}
	
# dev.off()





###############################
#					#
#		FIG 3 B		#
# 		Validation		#
#		ASL_CF		#
#					#
###############################

Tarran2 = read.csv("Tarran_ASL_data2.csv")
Tarran3 = read.csv("Tarran_ASL_data3.csv")
Button_CF = read.csv("Button_ASL_CF_data.csv") 
Sandefur = read.csv("Sandefur_ASL_data.csv")


tmax=3000
tstep=1
t=seq(0,tmax+1,tstep) 	# time

# Inicial states for variables
# insert, in the parentesis, the inicial value of the dependent variables (ex: X=2) 
state_CF=c(
	ENaC = 80,
	ASL = 25
	) 

parameters_CF = parameters
parameters_CF[names(parameters_CF)=='SPLUNC1']=0
parameters_CF[names(parameters_CF)=='gamma_CFTR_ASL']=0

# tiff("P2FS3B_CF.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

# data
par(mar=c(5,6,4,1)+.1)
plot(Tarran2$X*60,Tarran2$Y_no_SPLUNC1,pch=17,
	xlim=c(0,3000),ylim = c(0,40),
	main='CF ASL', xlab='Time (min)',ylab='ASL thickness',
	cex.lab=3,cex.axis=2,cex.main=3,
	cex=3,col='black'
	) 
points(Tarran3$X*60,Tarran3$Y_CF,pch=18,cex=3,col='red') 
points(Button_CF$X*60,Button_CF$Y,pch=15,cex=3,col='green')
segments(x0=Button_CF$X*60,y0=Button_CF$Y_lower,x1=Button_CF$X*60,y1=Button_CF$Y_upper,col='green',lwd=3)   
points(Sandefur$X*60,Sandefur$Y_CF,pch=16,cex=3,col='violet')
segments(x0=Sandefur$X*60,y0=Sandefur$Y_CF_DW,x1=Sandefur$X*60,y1=Sandefur$Y_CF_UP,col='violet',lwd=3) 

abline(h=4,col='orange')

legend (x = 'topright', 							# position
	legend = c('Hobbs et al. data','Tarran et al. data','Button et al. data','Sandefur et al. data'),	# legend's text  
	text.col =  c('black','red','green','violet'),
	pch=c(17,18,15,16),						# legend's objects point character 
	col =  c('black','red','green','violet'),
	cex = 3,								# font size for legend
	bty = "n"								# no legend box
	)

plot_colors = c('black','red','green','violet')
CF_ASL_starts=c(31.276586,25.993151,35.005454,28.027118)
for (i in 1:4)
	{
	state_CF=c(
		ENaC = 80,
		ASL = CF_ASL_starts[i]
		) 
	out = Cruncher(state_CF,t,equations,parameters_CF)
	points(out[,1],out[,3],type='l',col=plot_colors[i],lwd=3)		
	}

# dev.off()










#####################################
#						#
#		FIG 5				#
#		Validation			#
#	Alma�a ENaC activity data	#
#						#
#####################################

Almaca_N_Po = read.csv("Almaca_N_Po.csv")
Almaca_N_Po_norm = Almaca_N_Po / Almaca_N_Po$WT[1]


tmax=100000
tstep=1
t=seq(0,tmax+1,tstep)

##################################### Perturb ####################################
ptime=c(0,10000,20000,30000,30005,80000,max(t));
pvar=c('novar','PI45P2','PI45P2','SPLUNC1','gamma_CFTR_ASL','PI45P2','novar')
pval=c(NA,9000,10000,0,0,9000,NA)
perturbations=data.frame(time=ptime,var=pvar,val=pval)
perturbations
# use 8500 for the bars to all be within the confidence intervals

out = Cruncher(state,t,equations,parameters,perturbations)

varnames=c('Time (s)','ENaC','ASL') 
varcolors=c('gray','darkblue','cyan')
#  cbind(1:length(varnames),varnames,varcolors)

# naming fluxes in out
flux_names=c(
		'V__ENaC','V_ENaC_SPLUNC1','V_ENaC_',
		'V__ASL','V_CFTR_ASL','V_ASL_ENaC','V_ASL_'
		)
colnames(out)[(length(state)+2):dim(out)[2]]=flux_names

# time plot
par(mfrow=c(2,1))
for (i in c(2:3)) 
	{
	plot(out[,1],out[,i],type='l',col=varcolors[i])
	text(tmax,out[tmax-1,i],varnames[i],col=varcolors[i])
	}
par(mfrow=c(1,1))

sample_NPo = c(
		as.numeric(out[9990,2])*ENaC_op(10000),
		as.numeric(out[19990,2])*ENaC_op(9000),
		as.numeric(out[49990,2])*ENaC_op(10000),
		as.numeric(out[69990,2])*ENaC_op(9000)
		)

normalized_sample_NPo = sample_NPo / sample_NPo[1]



# tiff("P2_FigS5A_Almaca.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

par(mar=c(6,6,4,1)+.1)
barplot(
	height=normalized_sample_NPo,
	width = .9, space = .1,
	#names.arg = c(expression('PIP'[2]*' basal'),expression('PIP'[2]*' low'),expression('PIP'[2]*' basal'),expression('PIP'[2]*' low')),
	ylim=c(0,3),
	main='Alma�a et al. data on ENaC activity',
	ylab=expression('N*P'[o]),
	cex.axis=2,cex.main=3, cex.lab=3,cex.names=3
	)
axis(1, at=(1:4)-.5, tick=FALSE,
	labels = c(expression('PIP'[2]*' basal'),expression('PIP'[2]*' low'),expression('PIP'[2]*' basal'),expression('PIP'[2]*' low')), 
	cex.axis = 3,
	pos=-.1)
axis(1, at=c(1.05,3.05), tick=FALSE,
	labels = c('__________________','__________________'), 
	cex.axis = 3,
	pos=-.08)
axis(1, at=c(1,3), tick=FALSE,
	labels = c('HL','CF'), 
	cex.axis = 3,
	pos=-.4,line=1)

points(x=c(.5,1.5,2.5,3.5),y=c(Almaca_N_Po_norm$WT_lower,Almaca_N_Po_norm$CF_lower),col='black', pch = "_", cex = 3)
text(x=c(.5,1.5,2.5,3.5),y=c(Almaca_N_Po_norm$WT,Almaca_N_Po_norm$CF),labels='___',cex = 3)
points(x=c(.5,1.5,2.5,3.5),y=c(Almaca_N_Po_norm$WT_upper,Almaca_N_Po_norm$CF_upper),col='black', pch = "_", cex = 3)

segments(
	x0=c(.5,1.5,2.5,3.5),y0=c(Almaca_N_Po_norm$WT_lower,Almaca_N_Po_norm$CF_lower),
	x1=c(.5,1.5,2.5,3.5),y1=c(Almaca_N_Po_norm$WT_upper,Almaca_N_Po_norm$CF_upper),	
	col='black',lwd=3
	) 

# dev.off()










###############################
#					#
#	Choi_ASL_SPLUNC1		#
#					#
# 		Validation		#
#					#
###############################

### ASL timecourses with different SPLUNC1 concentrations ### OK

Tarran_ASL_SPLUNC1_1 = read.csv("Tarran_ASL_SPLUNC1_data_1.csv")

tmax=3000
tstep=1
t=seq(0,tmax+1,tstep) 	# time

# setting WT conditions
state_ASL_SPLUNC1=c(
			ENaC = 35.00237,
			ASL = 7.000844
			) 

parameters_ASL_SPLUNC1 = parameters
parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='SPLUNC1'] = parameters[names(parameters)=='SPLUNC1']
parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='gamma_CFTR_ASL'] = parameters[names(parameters)=='gamma_CFTR_ASL']

# tiff("P2_FIGSS6.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

ASL_SPLUNC1_starts = as.numeric(Tarran_ASL_SPLUNC1_1[1,2:5])
SPLUNC1 = c(0.1,10,25,100) * 6.02214076e2
legend_1 = c(
		expression(paste('SPLUNC1 = 0.1 ',mu,'M')),
		expression(paste('SPLUNC1 = 10 ',mu,'M')),
		expression(paste('SPLUNC1 = 25 ',mu,'M')),
		expression(paste('SPLUNC1 = 100 ',mu,'M'))
		)
par(mfrow=c(2,2),mar=c(5,6,4,1)+.1)
for (i in 1:4)
	{
	# data
	plot(Tarran_ASL_SPLUNC1_1$X*60,Tarran_ASL_SPLUNC1_1[,i+1],
	xlim=c(0,3000),ylim=c(0,40),
	xlab = 'min', ylab = expression(paste('ASL thickness (',mu,'m)')),
	cex.lab=2.5,cex.axis=2,cex.main=3,
	pch=16,cex=2
	)
	text(x=2000,y=30,label = legend_1[i],cex=2)
	state_ASL_SPLUNC1=c(
				ENaC = 35.00237,
				ASL = ASL_SPLUNC1_starts[i]
				) 
	parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='SPLUNC1']=SPLUNC1[i] * ASL_SPLUNC1_starts[i]
	out = Cruncher(state_ASL_SPLUNC1,t,equations,parameters_ASL_SPLUNC1)
	points(out[,1],out[,3],type='l',col='blue',lwd=3)		
	}

# dev.off()


### Fig S4A
### Model fitting
### ASL acording to SPLUNC1 concentrations ###	

# tiff("P2_FIGSS4A.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

# Data
Tarran_ASL_SPLUNC1_2 = read.csv("Tarran_ASL_SPLUNC1_data_2.csv")
par(mfrow=c(1,1),mar=c(5,6,4,1)+.1)
plot(Tarran_ASL_SPLUNC1_2$X,Tarran_ASL_SPLUNC1_2$SPLUNC1,
	xlim = c(-3,5),ylim = c(5,14),pch = 19,cex = 1.5,col = 'black',
	xlab = expression(paste('log'[10],'[SPLUNC1] (',mu,'M)')), 
	ylab = expression(paste('ASL thickness (',mu,'m)')),
	cex.lab=2,cex.axis=2,cex.main=3
	)
segments(x0=Tarran_ASL_SPLUNC1_2$X,y0=Tarran_ASL_SPLUNC1_2$SPLUNC1_DW,
	x1=Tarran_ASL_SPLUNC1_2$X,y1=Tarran_ASL_SPLUNC1_2$SPLUNC1_UP,
	col='black',lwd=3) 
legend(
	'topleft',legend=c('data','model 4H','model STST'),
	col=c('black','blue','cyan'),bty='n',cex=2,
	lwd=c(5,5,5)
	)  

# Model
tmax=5000; tstep=1; t=seq(0,tmax+1,tstep) 	# time
state_ASL_SPLUNC1 = state
state_ASL_SPLUNC1[2]=25
parameters_ASL_SPLUNC1=parameters
aux1=vector()
aux2=vector()
aux3=vector()
for (i in seq(-3,5,.1)) 
	{
	parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='SPLUNC1']= 10^(i) * 6.02214076e2 * 25
	out = Cruncher(state_ASL_SPLUNC1,t,equations,parameters_ASL_SPLUNC1)
	points(i,out[240,3],cex=.5,col='blue')
	aux1=c(aux1,out[4999,3])
	aux3=c(aux3,out[240,3])
	aux2=c(aux2,out[4999,2])	
	}
points(seq(-3,5,.1),aux1,type='l',col='cyan',lwd=5)
points(seq(-3,5,.1),aux3,type='l',col='blue',lwd=5)


#for (i in 1:7) 
#	{
#	parameters_ASL_SPLUNC1[names(parameters_ASL_SPLUNC1)=='SPLUNC1']= 10^(Tarran_ASL_SPLUNC1_2$X[i]) * 6.02214076e2 * 25
#	out = Cruncher(state,t,equations,parameters_ASL_SPLUNC1)
#	points(Tarran_ASL_SPLUNC1_2$X[i],out[4999,3],pch=3,col='blue')	
#	}

# dev.off()



### Fig S4B
# tiff("P2_FIGS4B.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

par(mfrow=c(1,1),mar=c(5,6,4,1)+.1)
plot(
	seq(-3,5,.1),aux2,	
	type='l',col='green',lwd=5,
	xaxt='n', 
	xlab = NA,
	ylab = expression(paste('ENaC (molecules/',mu,'m'^2,')')),
	cex.lab=2,cex.axis=2,cex.main=3
	)
axis(side=3,cex.axis=2)

# dev.off()


### FigS8
### Validation
### ASL in WT and CF with ATP addition ###	Not OK

# Model 
model = c(7,0,4,0)
tmax=5000; tstep=1; t=seq(0,tmax+1,tstep) 	# time
# WT
state_ASL_SPLUNC1_WT = state
parameters_ASL_SPLUNC1_WT = parameters
parameters_ASL_SPLUNC1_WT[names(parameters_ASL_SPLUNC1_WT)=='PI45P2'] = 5000
parameters_ASL_SPLUNC1_WT[names(parameters_ASL_SPLUNC1_WT)=='gamma__ASL'] = 5.915000e-02*1.375
parameters_ASL_SPLUNC1_WT[names(parameters_ASL_SPLUNC1_WT)=='gamma_CFTR_ASL'] = 2.388750e-02*1.5
out_ASL_SPLUNC1_WT = Cruncher(state_ASL_SPLUNC1_WT,t,equations,parameters_ASL_SPLUNC1_WT)
plot(out_ASL_SPLUNC1_WT[,1],out_ASL_SPLUNC1_WT[,3])
model[2]=out_ASL_SPLUNC1_WT[4999,3]	
# CF	
state_ASL_SPLUNC1_CF=c(ENaC = 80,ASL = 4) 
parameters_ASL_SPLUNC1_CF = parameters
parameters_ASL_SPLUNC1_CF[names(parameters_ASL_SPLUNC1_CF)=='SPLUNC1']=0
parameters_ASL_SPLUNC1_CF[names(parameters_ASL_SPLUNC1_CF)=='gamma_CFTR_ASL']=0
parameters_ASL_SPLUNC1_CF[names(parameters_ASL_SPLUNC1_CF)=='PI45P2'] = 5000
parameters_ASL_SPLUNC1_CF[names(parameters_ASL_SPLUNC1_CF)=='gamma__ASL'] = 5.915000e-02*1.375
out_ASL_SPLUNC1_CF = Cruncher(state_ASL_SPLUNC1_CF,t,equations,parameters_ASL_SPLUNC1_CF)
plot(out_ASL_SPLUNC1_CF[,1],out_ASL_SPLUNC1_CF[,3])
model[4]=out_ASL_SPLUNC1_CF[4999,3]

# tiff("P2_Fig_S8.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

par(mfrow=c(1,1),mar=c(5,6,4,1)+.1)
barplot(
	model,ylim=c(0,20),
	ylab = expression(paste('ASL thickness (',mu,'m)')),
	cex.lab=2,cex.axis=2,cex.main=3
	)
axis(1, at=c(.75,1.95,3.05,4.3), tick=FALSE,
	labels = c('Vehicle','ATP','Vehicle','ATP'), 
	cex.axis = 2,
	pos=-.1)
axis(1, at=c(1.35,3.675), tick=FALSE,
	labels = c('__________________','__________________'), 
	cex.axis = 3,
	pos=-.08)
axis(1, at=c(1.35,3.675), tick=FALSE,
	labels = c('HL','CF'), 
	cex.axis = 2,
	pos=-1.4,line=1)

# Data
Tarran_ASL_SPLUNC1_3 = read.csv("Tarran_ASL_SPLUNC1_data_3.csv")
# Tarran_ASL_SPLUNC1_3 = Tarran_ASL_SPLUNC1_3[1:4,2:4] / Tarran_ASL_SPLUNC1_3[1,3]
#plot(Tarran_ASL_SPLUNC1_3$ASL_ATP,pch='-',cex=3,xlim=c(0,5),ylim=c(0,2))
text(x=c(.75,1.95,3.05,4.3),y=Tarran_ASL_SPLUNC1_3$ASL_ATP,labels='___',cex = 3)
segments(x0=c(.75,1.95,3.05,4.3),y0=Tarran_ASL_SPLUNC1_3$ASL_ATP_DW,
	x1=c(.75,1.95,3.05,4.3),y1=Tarran_ASL_SPLUNC1_3$ASL_ATP_UP,
	lwd=3)   
points(x=c(.75,1.95,3.05,4.3),y=Tarran_ASL_SPLUNC1_3$ASL_ATP_DW,pch='_',cex=3)
points(x=c(.75,1.95,3.05,4.3),y=Tarran_ASL_SPLUNC1_3$ASL_ATP_UP,pch='_',cex=3)

# dev.off()










###############################
#					#
#		FigS7			#
#		Validation  	#
#		P2Y2			#
#					#
###############################

# tiff("P2_FIGS7_P2Y2.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

### Data ###
P2Y2_ASL = read.csv("P2Y2_ASL.csv")
P2Y2_ag = read.csv("P2Y2_ag.csv")
par(mfrow=c(2,1),mar=c(5,6,4,1)+.1)
plot(
	P2Y2_ag$X*60,P2Y2_ag$Y/P2Y2_ag$Y[1],type='p',
	xlab='Time (min)',ylab=expression('P2Y'[2]*' agonist'),
	pch=16,
	cex.lab=2.5,cex.axis=2,cex.main=3
	)
 
plot(
	P2Y2_ASL$X*60,P2Y2_ASL$WT,
	type='p',col='lightblue',
	ylim=c(0,15),pch=16,
	xlab='Time (min)',ylab=expression(paste('ASL thickness (',mu,'m)')),
	cex.lab=2.5,cex.axis=2,cex.main=3
	)
segments(x0=P2Y2_ASL$X*60,y0=P2Y2_ASL$WT_LW,
	x1=P2Y2_ASL$X*60,y1=P2Y2_ASL$WT_UP,
	col='lightblue',lwd=3)   
points(P2Y2_ASL$X*60,P2Y2_ASL$CF,type='p',col='pink',pch=16)
segments(x0=P2Y2_ASL$X*60,y0=P2Y2_ASL$CF_LW,
	x1=P2Y2_ASL$X*60,y1=P2Y2_ASL$CF_UP,
	col='pink',lwd=3) 
legend("bottomright",legend=c('WT','CF'),col=c('blue','red'),lwd=5,bty = "n")

### Model WT ###

tmax=3000
tstep=1
t=seq(0,tmax+1,tstep) 	# time


##################################### Perturb ####################################
a = round(P2Y2_ag$X*60,0)
b = round(P2Y2_ag$X*60,0)+3
c = round(P2Y2_ag$X*60,0)+6
x=c(rbind(a,b,c)) 

ptime=c(0,x,max(t))
pvar=c('novar',rep(c('PI45P2','gamma__ASL','gamma_CFTR_ASL'),length(ptime)/3 ),'novar')

a1 = 10000*(P2Y2_ag$Y[1]/P2Y2_ag$Y)
b1 = parameters[names(parameters)=='gamma__ASL']*(((P2Y2_ag$Y/P2Y2_ag$Y[1])-1)*(2/4)+1)
c1 = parameters[names(parameters)=='gamma_CFTR_ASL']*(P2Y2_ag$Y/P2Y2_ag$Y[1])
y = c(rbind(a1,b1,c1))

pval=c(NA,y,NA)

perturbations=data.frame(time=ptime,var=pvar,val=pval)
perturbations

state_P2Y2 = state
state_P2Y2[2] = 7.25 

out = Cruncher(state_P2Y2,t,equations,parameters,perturbations)
points(
	out[,1],out[,3],
	type='l',col='blue',lwd=5
	)

### Model  CF ###

tmax=3000
tstep=1
t=seq(0,tmax+1,tstep) 	# time

# Inicial states for variables
# insert, in the parentesis, the inicial value of the dependent variables (ex: X=2) 
state_CF=c(
	ENaC = 80,
	ASL = 3.45
	) 

parameters_CF = parameters
parameters_CF[names(parameters_CF)=='SPLUNC1']=0
parameters_CF[names(parameters_CF)=='gamma_CFTR_ASL']=0

##################################### Perturb ####################################
a = round(P2Y2_ag$X*60,0)
b = round(P2Y2_ag$X*60,0)+3
c = round(P2Y2_ag$X*60,0)+6
x=c(rbind(a,b,c)) 

ptime=c(0,x,max(t))
pvar=c('novar',rep(c('PI45P2','gamma__ASL','gamma_CFTR_ASL'),length(ptime)/3 ),'novar')

a1 = 10000*(P2Y2_ag$Y[1]/P2Y2_ag$Y)
b1 = parameters_CF[names(parameters_CF)=='gamma__ASL']*(((P2Y2_ag$Y/P2Y2_ag$Y[1])-1)*(2/4)+1)
c1 = parameters_CF[names(parameters_CF)=='gamma_CFTR_ASL']*(P2Y2_ag$Y/P2Y2_ag$Y[1])
y = c(rbind(a1,b1,c1))

pval=c(NA,y,NA)

perturbations_CF = data.frame(time=ptime,var=pvar,val=pval)
perturbations_CF

out = Cruncher(state_CF,t,equations,parameters_CF,perturbations_CF)
points(
	out[,1],out[,3],
	type='l',col='red',lwd=5
	)

# dev.off()










###################
#			#
#	Wu data 	#
#			#
###################

Wu = read.csv("Wu_data.csv")

op <- par(no.readonly = TRUE)

# tiff("P2_Wu_NL.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)
# NL
par(mfrow=c(1,1),mar=c(16, 6, 4, 2) + 0.1)
plot(
	1:dim(Wu)[1],Wu$NL,
	col='grey',pch=0,cex=2,
	ylim=c(0,20),
	main='Healthy Lungs',xlab='',ylab=expression(paste('ASL thickness (',mu,'m)')),
	xaxt = "n",
	cex.lab=2,cex.axis=2,cex.main=2
	)
axis(1, at=1:12, labels=Wu$Label,las = 2,cex.axis=1.5)
abline(h=7,col='blue')
segments(x0=1:dim(Wu)[1],y0=Wu$NL_DW,
	x1=1:dim(Wu)[1],y1=Wu$NL_UP,
	col='black',lwd=3) 
points(
	1:dim(Wu)[1],Wu$NL,
	col='white',pch=15,cex=2
	)
points(
	1:dim(Wu)[1],Wu$NL,
	col='black',pch=0,cex=2
	)


a=5000

# NL Model 
model_Wu_NL = vector()
tmax=30000; tstep=1; t=seq(0,tmax+1,tstep) 	# time
state_Wu = state
parameters_Wu_NL = parameters

# CSS
parameters_Wu_NL_CSS = parameters
parameters_Wu_NL_CSS[names(parameters_Wu_NL_CSS)=='PI45P2'] = a
parameters_Wu_NL_CSS[names(parameters_Wu_NL_CSS)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
parameters_Wu_NL_CSS[names(parameters_Wu_NL_CSS)=='gamma_CFTR_ASL'] = parameters[names(parameters)=='gamma_CFTR_ASL']*1.5
out_Wu_NL_CSS = Cruncher(state_Wu,t,equations,parameters_Wu_NL_CSS)
# plot(out_Wu_NL_CSS[,1],out_Wu_NL_CSS[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_CSS[4999,3])

# CSS + CFTR_inh172
parameters_Wu_NL_CSS_CFTR_inh172 = parameters
parameters_Wu_NL_CSS_CFTR_inh172[names(parameters_Wu_NL_CSS_CFTR_inh172)=='PI45P2'] = a
parameters_Wu_NL_CSS_CFTR_inh172[names(parameters_Wu_NL_CSS_CFTR_inh172)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
parameters_Wu_NL_CSS_CFTR_inh172[names(parameters_Wu_NL_CSS_CFTR_inh172)=='gamma_CFTR_ASL'] = 0
out_Wu_NL_CSS_CFTR_inh172 = Cruncher(state_Wu,t,equations,parameters_Wu_NL_CSS_CFTR_inh172)
# plot(out_Wu_NL_CSS_CFTR_inh172[,1],out_Wu_NL_CSS_CFTR_inh172[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_CSS_CFTR_inh172[4999,3])

# CSS + CFTR_inh172 * DIDS
parameters_Wu_NL_CSS_CFTR_inh172_DIDS = parameters
parameters_Wu_NL_CSS_CFTR_inh172_DIDS[names(parameters_Wu_NL_CSS_CFTR_inh172_DIDS)=='PI45P2'] = a
parameters_Wu_NL_CSS_CFTR_inh172_DIDS[names(parameters_Wu_NL_CSS_CFTR_inh172_DIDS)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*(.75)
parameters_Wu_NL_CSS_CFTR_inh172_DIDS[names(parameters_Wu_NL_CSS_CFTR_inh172_DIDS)=='gamma_CFTR_ASL'] = 0
out_Wu_NL_CSS_CFTR_inh172_DIDS = Cruncher(state_Wu,t,equations,parameters_Wu_NL_CSS_CFTR_inh172_DIDS)
# plot(out_Wu_NL_CSS_CFTR_inh172_DIDS[,1],out_Wu_NL_CSS_CFTR_inh172_DIDS[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_CSS_CFTR_inh172_DIDS[4999,3])

# CSS + Apyrase
parameters_Wu_NL_CSS_Apyrase = parameters
parameters_Wu_NL_CSS_Apyrase[names(parameters_Wu_NL_CSS_Apyrase)=='PI45P2'] = 10000+(10000-a) 
parameters_Wu_NL_CSS_Apyrase[names(parameters_Wu_NL_CSS_Apyrase)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*(.75)
parameters_Wu_NL_CSS_Apyrase[names(parameters_Wu_NL_CSS_Apyrase)=='gamma_CFTR_ASL'] = parameters[names(parameters)=='gamma_CFTR_ASL']*1.5
out_Wu_NL_CSS = Cruncher(state_Wu,t,equations,parameters_Wu_NL_CSS)
out_Wu_NL_CSS_Apyrase = Cruncher(state_Wu,t,equations,parameters_Wu_NL_CSS_Apyrase)
# plot(out_Wu_NL_CSS_Apyrase[,1],out_Wu_NL_CSS_Apyrase[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_CSS_Apyrase[4999,3])

# CSS + 8SPT
parameters_Wu_NL_CSS_8SPT = parameters
parameters_Wu_NL_CSS_8SPT[names(parameters_Wu_NL_CSS_8SPT)=='PI45P2'] = a
parameters_Wu_NL_CSS_8SPT[names(parameters_Wu_NL_CSS_8SPT)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
parameters_Wu_NL_CSS_8SPT[names(parameters_Wu_NL_CSS_8SPT)=='gamma_CFTR_ASL'] = parameters[names(parameters)=='gamma_CFTR_ASL']*.5
out_Wu_NL_CSS_8SPT = Cruncher(state_Wu,t,equations,parameters_Wu_NL_CSS_8SPT)
# plot(out_Wu_NL_CSS_8SPT[,1],out_Wu_NL_CSS_8SPT[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_CSS_8SPT[4999,3])

# CSS + 8SPT + Apyrase
parameters_Wu_NL_CSS_8SPT_Apyrase = parameters
parameters_Wu_NL_CSS_8SPT_Apyrase[names(parameters_Wu_NL_CSS_8SPT_Apyrase)=='PI45P2'] = 10000+(10000-a)
parameters_Wu_NL_CSS_8SPT_Apyrase[names(parameters_Wu_NL_CSS_8SPT_Apyrase)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
parameters_Wu_NL_CSS_8SPT_Apyrase[names(parameters_Wu_NL_CSS_8SPT_Apyrase)=='gamma_CFTR_ASL'] = parameters[names(parameters)=='gamma_CFTR_ASL']*.5
out_Wu_NL_CSS_8SPT_Apyrase = Cruncher(state_Wu,t,equations,parameters_Wu_NL_CSS_8SPT_Apyrase)
# plot(out_Wu_NL_CSS_8SPT_Apyrase[,1],out_Wu_NL_CSS_8SPT_Apyrase[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_CSS_8SPT_Apyrase[4999,3])

# Bumetanide
parameters_Wu_NL_Bu = parameters
parameters_Wu_NL_Bu[names(parameters_Wu_NL_Bu)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*(.75)
parameters_Wu_NL_Bu[names(parameters_Wu_NL_Bu)=='gamma_CFTR_ASL'] = 0
out_Wu_NL_Bu = Cruncher(state_Wu,t,equations,parameters_Wu_NL_Bu)
# plot(out_Wu_NL_Bu[,1],out_Wu_NL_Bu[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_Bu[4999,3])

# Nystatin
parameters_Wu_NL_Ny = parameters
parameters_Wu_NL_Ny[names(parameters_Wu_NL_Ny)=='gamma_ASL_'] = parameters[names(parameters)=='gamma_ASL_']*3
out_Wu_NL_Ny = Cruncher(state_Wu,t,equations,parameters_Wu_NL_Ny)
# plot(out_Wu_NL_Ny[,1],out_Wu_NL_Ny[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_Ny[4999,3])

# Trypsin + ADO300uM
parameters_Wu_NL_Tryp_ADO = parameters
parameters_Wu_NL_Tryp_ADO[names(parameters_Wu_NL_Tryp_ADO)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*2
parameters_Wu_NL_Tryp_ADO[names(parameters_Wu_NL_Tryp_ADO)=='gamma_CFTR_ASL'] = parameters[names(parameters)=='gamma_CFTR_ASL']*1.5
out_Wu_NL_Tryp_ADO = Cruncher(state_Wu,t,equations,parameters_Wu_NL_Tryp_ADO)
# plot(out_Wu_NL_Tryp_ADO[,1],out_Wu_NL_Tryp_ADO[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_Tryp_ADO[4999,3])

# Aprotinin + ADO300uM
parameters_Wu_NL_Apro_ADO = parameters
parameters_Wu_NL_Apro_ADO[names(parameters_Wu_NL_Apro_ADO)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*.01
parameters_Wu_NL_Apro_ADO[names(parameters_Wu_NL_Apro_ADO)=='gamma_CFTR_ASL'] = parameters[names(parameters)=='gamma_CFTR_ASL']*1.5
out_Wu_NL_Apro_ADO = Cruncher(state_Wu,t,equations,parameters_Wu_NL_Apro_ADO)
# plot(out_Wu_NL_Apro_ADO[,1],out_Wu_NL_Apro_ADO[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_Apro_ADO[4999,3])

# Trypsin + ATP300uM
parameters_Wu_NL_Tryp_ATP = parameters
parameters_Wu_NL_Tryp_ATP[names(parameters_Wu_NL_Tryp_ATP)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*2
parameters_Wu_NL_Tryp_ATP[names(parameters_Wu_NL_Tryp_ATP)=='PI45P2'] = a
parameters_Wu_NL_Tryp_ATP[names(parameters_Wu_NL_Tryp_ATP)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
parameters_Wu_NL_Tryp_ATP[names(parameters_Wu_NL_Tryp_ATP)=='gamma_CFTR_ASL'] = parameters[names(parameters)=='gamma_CFTR_ASL']*1.5
out_Wu_NL_Tryp_ATP = Cruncher(state_Wu,t,equations,parameters_Wu_NL_Tryp_ATP)
# plot(out_Wu_NL_Tryp_ATP[,1],out_Wu_NL_Tryp_ATP[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_Tryp_ATP[4999,3])

# Aprotinin + ATP300uM
parameters_Wu_NL_Apro_ATP = parameters
parameters_Wu_NL_Apro_ATP[names(parameters_Wu_NL_Apro_ATP)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*.01
parameters_Wu_NL_Apro_ATP[names(parameters_Wu_NL_Apro_ATP)=='PI45P2'] = a
parameters_Wu_NL_Apro_ATP[names(parameters_Wu_NL_Apro_ATP)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
parameters_Wu_NL_Apro_ATP[names(parameters_Wu_NL_Apro_ATP)=='gamma_CFTR_ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
out_Wu_NL_Apro_ATP = Cruncher(state_Wu,t,equations,parameters_Wu_NL_Apro_ATP)
# plot(out_Wu_NL_Apro_ATP[,1],out_Wu_NL_Apro_ATP[,3])
model_Wu_NL=c(model_Wu_NL,out_Wu_NL_Apro_ATP[4999,3])

points(1:length(model_Wu_NL),model_Wu_NL,pch='*',col='blue',cex=3)	

# dev.off()



#windows()
# tiff("P2_Wu_CF.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)
# CF 
par(mfrow=c(1,1),mar=c(16, 6, 4, 2) + 0.1)
plot(
	1:dim(Wu)[1],Wu$CF,
	col='grey',pch=0,cex=2,
	ylim=c(0,20),
	main='Cystic Fibrosis',xlab='',ylab=expression(paste('ASL thickness (',mu,'m)')),
	xaxt = "n",
	cex.lab=2,cex.axis=2,cex.main=2
	)
axis(1, at=1:12, labels=Wu$Label,las = 2,cex.axis=1.5)
abline(h=4,col='blue')
segments(x0=1:dim(Wu)[1],y0=Wu$CF_DW,
	x1=1:dim(Wu)[1],y1=Wu$CF_UP,
	col='black',lwd=3) 
points(
	1:dim(Wu)[1],Wu$CF,
	col='white',pch=15,,cex=2
	)
points(
	1:dim(Wu)[1],Wu$CF,
	col='black',pch=0,,cex=2
	)

# CF Model 
model_Wu_CF = vector()
state_Wu_CF=c(
	ENaC = 80,
	ASL = 4
	) 
parameters_Wu_CF = parameters
parameters_Wu_CF[names(parameters_Wu_CF)=='gamma_CFTR_ASL'] = 0
parameters_Wu_CF[names(parameters_Wu_CF)=='SPLUNC1'] = 0

# CSS
parameters_Wu_CF_CSS = parameters_Wu_CF
parameters_Wu_CF_CSS[names(parameters_Wu_CF_CSS)=='PI45P2'] = a
parameters_Wu_CF_CSS[names(parameters_Wu_CF_CSS)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
out_Wu_CF_CSS = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_CSS)
# plot(out_Wu_CF_CSS[,1],out_Wu_CF_CSS[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_CSS[4999,3])

# CSS + CFTR_inh172
parameters_Wu_CF_CSS_CFTR_inh172 = parameters_Wu_CF
parameters_Wu_CF_CSS_CFTR_inh172[names(parameters_Wu_CF_CSS_CFTR_inh172)=='PI45P2'] = a
parameters_Wu_CF_CSS_CFTR_inh172[names(parameters_Wu_CF_CSS_CFTR_inh172)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
out_Wu_CF_CSS_CFTR_inh172 = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_CSS_CFTR_inh172)
# plot(out_Wu_CF_CSS_CFTR_inh172[,1],out_Wu_CF_CSS_CFTR_inh172[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_CSS_CFTR_inh172[4999,3])

# CSS + CFTR_inh172 * DIDS
parameters_Wu_CF_CSS_CFTR_inh172_DIDS = parameters_Wu_CF
parameters_Wu_CF_CSS_CFTR_inh172_DIDS[names(parameters_Wu_CF_CSS_CFTR_inh172_DIDS)=='PI45P2'] = a
parameters_Wu_CF_CSS_CFTR_inh172_DIDS[names(parameters_Wu_CF_CSS_CFTR_inh172_DIDS)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*(.75)
out_Wu_CF_CSS_CFTR_inh172_DIDS = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_CSS_CFTR_inh172_DIDS)
# plot(out_Wu_CF_CSS_CFTR_inh172_DIDS[,1],out_Wu_CF_CSS_CFTR_inh172_DIDS[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_CSS_CFTR_inh172_DIDS[4999,3])

# CSS + Apyrase
parameters_Wu_CF_CSS_Apyrase = parameters_Wu_CF
parameters_Wu_CF_CSS_Apyrase[names(parameters_Wu_CF_CSS_Apyrase)=='PI45P2'] = 10000+(10000-a) 
parameters_Wu_CF_CSS_Apyrase[names(parameters_Wu_CF_CSS_Apyrase)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*(.75)
out_Wu_CF_CSS_Apyrase = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_CSS_Apyrase)
# plot(out_Wu_CF_CSS_Apyrase[,1],out_Wu_CF_CSS_Apyrase[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_CSS_Apyrase[4999,3])

# CSS + 8SPT
parameters_Wu_CF_CSS_8SPT = parameters_Wu_CF
parameters_Wu_CF_CSS_8SPT[names(parameters_Wu_CF_CSS_8SPT)=='PI45P2'] = a
parameters_Wu_CF_CSS_8SPT[names(parameters_Wu_CF_CSS_8SPT)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
out_Wu_CF_CSS_8SPT = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_CSS_8SPT)
# plot(out_Wu_CF_CSS_8SPT[,1],out_Wu_CF_CSS_8SPT[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_CSS_8SPT[4999,3])

# CSS + 8SPT + Apyrase
parameters_Wu_CF_CSS_8SPT_Apyrase = parameters
parameters_Wu_CF_CSS_8SPT_Apyrase[names(parameters_Wu_CF_CSS_8SPT_Apyrase)=='PI45P2'] = 10000+(10000-a)
parameters_Wu_CF_CSS_8SPT_Apyrase[names(parameters_Wu_CF_CSS_8SPT_Apyrase)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
out_Wu_CF_CSS_8SPT_Apyrase = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_CSS_8SPT_Apyrase)
# plot(out_Wu_CF_CSS_8SPT_Apyrase[,1],out_Wu_CF_CSS_8SPT_Apyrase[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_CSS_8SPT_Apyrase[4999,3])

# Bumetanide
parameters_Wu_CF_Bu = parameters_Wu_CF
parameters_Wu_CF_Bu[names(parameters_Wu_CF_Bu)=='gamma__ASL'] =  parameters[names(parameters)=='gamma__ASL']*(.75)
out_Wu_CF_Bu = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_Bu)
# plot(out_Wu_CF_Bu[,1],out_Wu_CF_Bu[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_Bu[4999,3])

# Nystatin
parameters_Wu_CF_Ny = parameters_Wu_CF
parameters_Wu_CF_Ny[names(parameters_Wu_CF_Ny)=='gamma_ASL_'] = parameters[names(parameters)=='gamma_ASL_']*3
out_Wu_CF_Ny = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_Ny)
# plot(out_Wu_CF_Ny[,1],out_Wu_CF_Ny[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_Ny[4999,3])

# Trypsin + ADO300uM_Wu_CF
parameters_Wu_CF_Tryp_ADO = parameters_Wu_CF
parameters_Wu_CF_Tryp_ADO[names(parameters_Wu_CF_Tryp_ADO)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*2
out_Wu_CF_Tryp_ADO = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_Tryp_ADO)
# plot(out_Wu_CF_Tryp_ADO[,1],out_Wu_CF_Tryp_ADO[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_Tryp_ADO[4999,3])

# Aprotinin + ADO300uM
parameters_Wu_CF_Apro_ADO = parameters_Wu_CF
parameters_Wu_CF_Apro_ADO[names(parameters_Wu_CF_Apro_ADO)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*.01
out_Wu_CF_Apro_ADO = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_Apro_ADO)
# plot(out_Wu_CF_Apro_ADO[,1],out_Wu_CF_Apro_ADO[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_Apro_ADO[4999,3])

# Trypsin + ATP300uM
parameters_Wu_CF_Tryp_ATP = parameters_Wu_CF
parameters_Wu_CF_Tryp_ATP[names(parameters_Wu_CF_Tryp_ATP)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*2
parameters_Wu_CF_Tryp_ATP[names(parameters_Wu_CF_Tryp_ATP)=='PI45P2'] = a
parameters_Wu_CF_Tryp_ATP[names(parameters_Wu_CF_Tryp_ATP)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
out_Wu_CF_Tryp_ATP = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_Tryp_ATP)
# plot(out_Wu_CF_Tryp_ATP[,1],out_Wu_CF_Tryp_ATP[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_Tryp_ATP[4999,3])

# Aprotinin + ATP300uM
parameters_Wu_CF_Apro_ATP = parameters_Wu_CF
parameters_Wu_CF_Apro_ATP[names(parameters_Wu_CF_Apro_ATP)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*.01
parameters_Wu_CF_Apro_ATP[names(parameters_Wu_CF_Apro_ATP)=='PI45P2'] = a
parameters_Wu_CF_Apro_ATP[names(parameters_Wu_CF_Apro_ATP)=='gamma__ASL'] = parameters[names(parameters)=='gamma__ASL']*1.25
out_Wu_CF_Apro_ATP = Cruncher(state_Wu_CF,t,equations,parameters_Wu_CF_Apro_ATP)
# plot(out_Wu_CF_Apro_ATP[,1],out_Wu_CF_Apro_ATP[,3])
model_Wu_CF=c(model_Wu_CF,out_Wu_CF_Apro_ATP[4999,3])

points(1:length(model_Wu_CF),model_Wu_CF,pch='*',col='blue',cex=3)

# dev.off()



par(op)



