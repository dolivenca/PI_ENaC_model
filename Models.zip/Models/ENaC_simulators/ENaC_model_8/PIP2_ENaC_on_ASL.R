

###########################################
#							#
#	ASL with different PIP2 levels WT	#
#							#
###########################################

tmax=30000
tstep=1
t=seq(0,tmax+1,tstep) 
pip2 = seq(1000,20000,1000)
parameters_pip2 = parameters

pip2 = cbind(pip2,ASL=rep(NA,length(pip2)),ENaC=rep(NA,length(pip2)))
for (ix in 1:length(pip2[,1])) 
	{
	parameters_pip2[names(parameters_pip2)=='PI45P2']=pip2[ix,1]
	out = Cruncher(state,t,equations,parameters_pip2)	

#	varnames=c('Time (s)','ENaC','ASL') 
#	varcolors=c('gray','darkblue','cyan')
#	#  cbind(1:length(varnames),varnames,varcolors)
#
#	# naming fluxes in out
#	flux_names=c(
#			'V__ENaC','V_ENaC_SPLUNC1','V_ENaC_',
#			'V__ASL','V_CFTR_ASL','V_ASL_ENaC','V_ASL_'
#			)
#	colnames(out)[(length(state)+2):dim(out)[2]]=flux_names
#
#	# time plot
#	par(mfrow=c(2,1))
#	for (i in c(2:3)) 
#		{
#		plot(out[,1],out[,i],type='l',col=varcolors[i])
#		text(tmax,out[tmax-1,i],varnames[i],col=varcolors[i])
#		}
#	par(mfrow=c(1,1))

	pip2[ix,2] = tail(out,1)[3]
	pip2[ix,3] = tail(out,1)[2]
	}

plot(pip2[,1],pip2[,2],type='b',col='cyan',lwd=2,
	xlab = 'PI45P2 levels (molecules / �m^2)', ylab = 'ASL height (�m)'
	)
 





###########################################
#							#
#	ASL with different ENaC numbers WT	#
#							#
###########################################

tmax=30000
tstep=1
t=seq(0,tmax+1,tstep) 
enac_in = c(seq(.1,10,.1),seq(11,80,1))
parameters_ENaC = parameters

enac = cbind(enac_in,ASL=rep(NA,length(enac_in)),ENaC=rep(NA,length(enac_in)))
for (ix in 1:length(enac[,1])) 
	{
	parameters_ENaC[names(parameters_ENaC)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*enac[ix,1]
	out = Cruncher(state,t,equations,parameters_ENaC)	

#	varnames=c('Time (s)','ENaC','ASL') 
#	varcolors=c('gray','darkblue','cyan')
#	#  cbind(1:length(varnames),varnames,varcolors)
#
#	# naming fluxes in out
#	flux_names=c(
#			'V__ENaC','V_ENaC_SPLUNC1','V_ENaC_',
#			'V__ASL','V_CFTR_ASL','V_ASL_ENaC','V_ASL_'
#			)
#	colnames(out)[(length(state)+2):dim(out)[2]]=flux_names
#
#	# time plot
#	par(mfrow=c(2,1))
#	for (i in c(2:3)) 
#		{
#		plot(out[,1],out[,i],type='l',col=varcolors[i])
#		text(tmax,out[tmax-1,i],varnames[i],col=varcolors[i])
#		}
#	par(mfrow=c(1,1))

	enac[ix,2] = tail(out,1)[3]
	enac[ix,3] = tail(out,1)[2]
	}

plot(enac[,3],enac[,2],type='b',col='cyan',lwd=2,
	xlab = 'ENaC (channels / �m^2)', ylab = 'ASL height (�m)'
	)


# tiff("P2F1_Fig_ASL_sensitivity_A_WT.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)
par(mfrow=c(1,2))
plot(pip2[,1],pip2[,2],type='b',col='cyan',lwd=2,
	xlab = 'PI45P2 levels (molecules / �m^2)', ylab = 'ASL height (�m)'
	)
plot(enac[,3],enac[,2],type='b',col='cyan',lwd=2,
	xlab = 'ENaC (channels / �m^2)', ylab = 'ASL height (�m)'
	)
# dev.off()




###########################################
#							#
#	ASL with different PIP2 levels CF	#
#							#
###########################################

tmax=30000
tstep=1
t=seq(0,tmax+1,tstep) 
pip2_CF = seq(1000,20000,1000)
state_CF=c(
	ENaC = 80,
	ASL = 4.00098-2.226505e-07-4.52971e-14 
	) 
parameters_pip2_CF = parameters
parameters_pip2_CF[names(parameters_pip2_CF)=='SPLUNC1']=0 
parameters_pip2_CF[names(parameters_pip2_CF)=='gamma_CFTR_ASL']=0 

pip2_CF = cbind(pip2_CF,ASL=rep(NA,length(pip2_CF)),ENaC=rep(NA,length(pip2_CF)))
for (ix in 1:length(pip2[,1])) 
	{
	parameters_pip2_CF[names(parameters_pip2_CF)=='PI45P2']=pip2_CF[ix,1]
	out = Cruncher(state_CF,t,equations,parameters_pip2_CF)	

#	varnames=c('Time (s)','ENaC','ASL') 
#	varcolors=c('gray','darkblue','cyan')
#	#  cbind(1:length(varnames),varnames,varcolors)

#	# naming fluxes in out
#	flux_names=c(
#			'V__ENaC','V_ENaC_SPLUNC1','V_ENaC_',
#			'V__ASL','V_CFTR_ASL','V_ASL_ENaC','V_ASL_'
#			)
#	colnames(out)[(length(state)+2):dim(out)[2]]=flux_names

#	# time plot
#	par(mfrow=c(2,1))
#	for (i in c(2:3)) 
#		{
#		plot(out[,1],out[,i],type='l',col=varcolors[i])
#		text(tmax,out[tmax-1,i],varnames[i],col=varcolors[i])
#		}
#	par(mfrow=c(1,1))

	pip2_CF[ix,2] = tail(out,1)[3]
	pip2_CF[ix,3] = tail(out,1)[2]
	}

plot(pip2_CF[,1],pip2_CF[,2],type='b',col='cyan',lwd=2,
	xlab = 'PI45P2 levels (molecules / �m^2)', ylab = 'ASL height (�m)'
	)
 





###########################################
#							#
#	ASL with different ENaC numbers CF	#
#							#
###########################################

tmax=30000
tstep=1
t=seq(0,tmax+1,tstep) 
enac_in = c(seq(.1,10,.1),seq(11,80,1))
state_CF=c(
	ENaC = 80,
	ASL = 4.00098-2.226505e-07-4.52971e-14 
	) 
parameters_ENaC_CF = parameters
parameters_ENaC_CF[names(parameters_ENaC_CF)=='SPLUNC1']=0 
parameters_ENaC_CF[names(parameters_ENaC_CF)=='gamma_CFTR_ASL']=0 

enac_CF = cbind(enac_in,ASL=rep(NA,length(enac_in)),ENaC=rep(NA,length(enac_in)))
for (ix in 1:length(enac_CF[,1])) 
	{
	parameters_ENaC_CF[names(parameters_ENaC_CF)=='gamma__ENaC'] = parameters[names(parameters)=='gamma__ENaC']*enac_CF[ix,1]
	out = Cruncher(state_CF,t,equations,parameters_ENaC_CF)	

#	varnames=c('Time (s)','ENaC','ASL') 
#	varcolors=c('gray','darkblue','cyan')
#	#  cbind(1:length(varnames),varnames,varcolors)

#	# naming fluxes in out
#	flux_names=c(
#			'V__ENaC','V_ENaC_SPLUNC1','V_ENaC_',
#			'V__ASL','V_CFTR_ASL','V_ASL_ENaC','V_ASL_'
#			)
#	colnames(out)[(length(state)+2):dim(out)[2]]=flux_names

#	# time plot
#	par(mfrow=c(2,1))
#	for (i in c(2:3)) 
#		{
#		plot(out[,1],out[,i],type='l',col=varcolors[i])
#		text(tmax,out[tmax-1,i],varnames[i],col=varcolors[i])
#		}
#	par(mfrow=c(1,1))

	enac_CF[ix,2] = tail(out,1)[3]
	enac_CF[ix,3] = tail(out,1)[2]
	}

plot(enac_CF[,3],enac_CF[,2],type='b',col='cyan',lwd=2,
	xlab = 'ENaC (channels / �m^2)', ylab = 'ASL height (�m)'
	)

# save(pip2,enac,pip2_CF,enac_CF,file='ASL_perturb_model_A.Rdata')








#load(file='ASL_perturb_model_A.Rdata')
#load(file='ASL_perturb_model_B.Rdata')

# tiff("P2F1_Fig_9a.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

par(mar=c(7,8.5,4,2)+.1, mgp = c(6,2,0),mfrow=c(1,1))
plot(pip2[,1],pip2[,2],type='l',col='cyan',lwd=7,
	xlab = expression('PI(4,5)P'[2]*' levels (molecules / ' ~ �m ^2 ~ ')'), ylab = 'ASL height (�m)',
	xlim=c(0,max(pip2[,1])),ylim=c(1,11),cex.lab=4,cex.axis=3.5
	)

points(pip2_CF[,1],pip2_CF[,2],type='l',col='yellowgreen',lwd=7,
	xlim=c(0,max(pip2_CF[,1])),ylim=c(1,9)
	)

# dev.off()



# tiff("P2F1_Fig_9b.tiff", height = 20, width = 34, units = 'cm',compression = "lzw", res = 300)

par(mar=c(7,8.5,4,2)+.1, mgp = c(6,2,0),mfrow=c(1,1))
plot(enac[,3],enac[,2],type='l',col='cyan',lwd=7,
	xlab = expression('ENaC (channels / ' ~ �m^2 ~ ')'), ylab = 'ASL height (�m)',
	xlim=c(0,600), ylim=c(0,11),cex.lab=4,cex.axis=3.5
	)
points(enac_CF[,3],enac_CF[,2],type='l',col='yellowgreen',lwd=7,
	xlim=c(0,600), ylim=c(0,11)
	)

legend (x = 'topright', 						# position
	legend = c('HL','CF'),						# legend's text  
	lwd=c(5,5),								# lines 
	col =  c('cyan','yellowgreen'),
	cex = 3,								# font size for legend
	bty = "n"								# no legend box
	)

# dev.off()




### not used ###

plot(pip2_B[,1],pip2_B[,2],type='l',col='cyan',lwd=5,
	main='Model B',cex.main=2,xlab = expression('PI(4,5)P'[2]*' levels (molecules / ' ~ �m ^2 ~ ')'), ylab = 'ASL height (�m)',
	xlim=c(0,max(pip2_B[,1])),ylim=c(1,9)
	)
points(pip2_CF_B[,1],pip2_CF_B[,2],type='l',col='yellowgreen',lwd=5,
	xlim=c(0,max(pip2_CF_B[,1])),ylim=c(1,9)
	)

plot(enac_B[,3],enac_B[,2],type='l',col='cyan',lwd=5,
	xlab = expression('ENaC (channels / ' ~ �m^2 ~ ')'), ylab = 'ASL height (�m)',
	xlim=c(0,600), ylim=c(min(enac_B[,2],enac_CF_B[,2]),max(enac_B[,2],enac_CF_B[,2]))
	)
points(enac_CF_B[,3],enac_CF_B[,2],type='l',col='yellowgreen',lwd=5,
	xlim=c(0,600), ylim=c(min(enac_B[,2],enac_CF_B[,2]),max(enac_B[,2],enac_CF_B[,2]))
	)







