
					  ######################	
################################### ENaC simulator ###########################################
					  ######################	


# Probability of closing or openning 
par(mfrow=c(2,1))
plot(c(5000,10000,15000),1-c(0.1,0.6,0.95),xlim=c(0,20000),ylim=c(0,1),xlab="PI45P2",ylab="Close Probability")
plot(c(5000,10000,15000),c(0.1,0.6,0.95),xlim=c(0,20000),ylim=c(0,1),xlab="PI45P2",ylab="Open Probability")


### Finding a function to fit the open probability data
# manual try #
PIP2=0:20000
n=4
Vmax=1
Km=9000
points(PIP2,Vmax*PIP2^n/(Km^n + PIP2^n),type='l',col='blue')
# try with TI-83 optimiser
points(PIP2,0.9962264151/(1+121.6307278*exp(-5.2159335E-4*PIP2)),type='l',col='green')
# try with TI-83 optimiser, round numbers to the 3rd decimal place
points(PIP2,0.996/(1+121.631*exp(-5.216E-4*PIP2)),type='l',col='green')
# try with TI-83 optimiser, round numbers to the 3rd decimal place
points(PIP2,1/(1+120*exp(-5.2E-4*PIP2)),type='l',col='cyan')
par(mfrow=c(1,1))

### figure for P2 ###
plot(c(5000,10000,15000),c(0.1,0.6,0.95),
	pch=15,
	xlim=c(0,20000),ylim=c(0,1),
	xlab="PI45P2 molecules / �m^2",ylab="ENaC Open Probability (Po)")
points(PIP2,1/(1+120*exp(-5.2E-4*PIP2)),type='l',col='black')


legend(x=15000,y=.4,
	legend=c('Data'),
	pch=c(15),
	bty = "n"	
	)
legend(x=13900,y=.35,
	lty=1,
	legend='Function',
	bty = "n"	
	)




### Open probability function for ENaC in function of PI45P2 and CFTR ###
ENaC_op = function(PIP2 = 10000,CFTR_WT=TRUE)
	{
	if(CFTR_WT==TRUE)
		{
		0.9962264151/(1+121.6307278*exp(-5.2159335E-4*PIP2))
		} else {
		1.7*(0.9962264151/(1+121.6307278*exp(-5.2159335E-4*PIP2)))
		}
	}
ENaC_op(PIP2=5000,CFTR_WT=TRUE)
ENaC_op(PIP2=10000,CFTR_WT=TRUE)
ENaC_op(PIP2=15000,CFTR_WT=TRUE)

ENaC_op(PIP2=5000,CFTR_WT=FALSE)
ENaC_op(PIP2=10000,CFTR_WT=FALSE)
ENaC_op(PIP2=15000,CFTR_WT=FALSE)


### to test models with the data for ENaC ### 

# Data
# When DGK is konckdown, PA should drop 50%
# In CF, because of SPLUNC1 inhibition, ENaC is 70% more active
# ENaC action should be normalized when DGK is knockdown

# Insert the number of time units that the simulation will run
tmax=5000
# Insert the step of the simulation
tstep=1
t=seq(0,tmax+1,tstep) 	# time

# Finaly remove the # form the front of all the next code lines
# On the first column put the time of the perturbation
ptime=c(0,1000,1500,2000,2500,3000,3500,max(t));
# On the second column put the variables to be altered. (ex: 'X')
pvar=c('novar','PLC','PLC','PLC','PLC','DGK','DGK','novar')
# On the third the new value for the variable.
pval=c(NA,
	state[18]*0.1,
	state[18],
	state[18]*4,
	state[18],
	parameters[names(parameters)=='DGK']*0.1,
	parameters[names(parameters)=='DGK'],
	NA)
perturbations=data.frame(time=ptime,var=pvar,val=pval)
perturbations

out = Cruncher(state,t,equations,parameters,perturbations)						# no perturbations			# with perturbations
# edit(out)
# View(out)

# normalized graphs
stst=out[500,]						# getting steady state at time 500
out_n=cbind(time=out[1],out[,2:ncol(out)])
#tail(out_n)
out_norm=out[,1]						# creating matrix out_norm to store the normalized information
for (i in 2:ncol(out))
	{
	newc=c(out_n[,i]/as.numeric(stst[i]))	# normalizing to steady state got at time 500
	out_norm=cbind(out_norm,newc)			# storing normalized information
	}
colnames(out_norm)=colnames(out)
#head(out_norm)
# edit(out_norm)

windows()
par(mfrow=c(3,3))
for (i in c(2:9)) 
	{
	plot(out_norm[,1],out_norm[,i],type='l',col=varcolors[i],xlab='Time',ylab='Fold change',main=varnames[i])
	text(tmax,out_norm[tmax,i],varnames[i],col=varcolors[i])
	}
par(mfrow=c(1,1))

windows()
par(mfrow=c(3,3))
for (i in c(2:9)) 
	{
	plot(out_norm[,1],out_norm[,i],type='l',col=varcolors[i],xlab='Time',ylab='Fold change',main=varnames[i])
	text(tmax,out_norm[tmax,i],varnames[i],col=varcolors[i])
	}
par(mfrow=c(1,1))

windows()
par(mfrow=c(3,3))
for (i in c(12,13,14,15,18,19,20)) 
	{
	plot(out_norm[,1],out_norm[,i],type='l',col=varcolors[i],xlab='Time',ylab='Fold change',main=varnames[i])
	text(tmax,out_norm[tmax,i],varnames[i],col=varcolors[i])
	}
par(mfrow=c(1,1))


windows()
plot(out[,1],ENaC_op(PIP2=out[,7],CFTR_WT=TRUE))











### First try - binomial distribution ###

# Creating 200 ENaC channels for a time course of 10000 time units #
nENaC=200

# use if time in seconds
ENaC=matrix(rep(NA,nENaC*tmax),ncol=tmax)
# store the information if the channel is open or closed in function of PI45P2 levels #

for(ii in 1:nENaC)
	{
	for (i in 1:tmax)
		{
		PIP2 = out[i,7]		
		ENaC[ii,i]=rbinom(1,1,1-(0.9962264151/(1+121.6307278*exp(-5.2159335E-4*PIP2))))
		}
	}

### use if time in minutes
ENaC=matrix(rep(NA,nENaC*tmax*60),ncol=(tmax*60))
### store the information if the channel is open or closed in function of PI45P2 levels #
for(ii in 1:nENaC)
	{
	for (i in 1:(tmax))
		{
		PIP2 = rep(out[i,7],60)	
		ENaC[ii,((i-1)*60+(1:60))]=rbinom(1,1,1-(0.9962264151/(1+121.6307278*exp(-5.2159335E-4*PIP2))))
		}
	}

ENaC
plot(1:(dim(ENaC)[2]),colSums(ENaC),type='s')

plot(1:(dim(ENaC)[2]),ENaC[1,],type='s',main="Binomial - Complete time course",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(290,290),y=c(0,1),c('O','C'),col=c('blue','blue'))





### simpler version - give values for PI45P2 and generate a time course of ENaC ###
# funtion to calculate ENaC time course in function of PI45P2 #
# Remember that close is 1 and open is 0 #
ENaC_tc = function(PIP2 = 10000,max_t = 60)
	{rbinom(max_t,1,1-(0.9962264151/(1+121.6307278*exp(-5.2159335E-4*PIP2))))}
ENaC_tc(PIP2=15000,max_t=300)

# to comper with data from Pochynyuk #
max_time = 300
windows()
par(mfrow=c(3,1))
plot(1:max_time,ENaC_tc(PIP2=10000,max_t=max_time),type='s',main="Basal PI45P2 ~ 10000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(max_time,max_time),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(1:max_time,ENaC_tc(PIP2=5000,max_t=max_time),type='s',main="Low PI45P2 ~ 5000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(max_time,max_time),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(1:max_time,ENaC_tc(PIP2=15000,max_t=max_time),type='s',main="High PI45P2 ~ 15000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(max_time,max_time),y=c(0,1),c('O','C'),col=c('blue','blue'))
par(mfrow=c(1,1))

# mean open time
1-sum(ENaC_tc(PIP2=10000,max_t=max_time))/300





### second try

# Mean close and open time of openning
par(mfrow=c(2,1))
plot(c(5000,10000,15000),c(4.500,1.200,0.200),xlim=c(0,20000),ylim=c(0,5),xlab="PI45P2",ylab="Mean Close Time")
PIP2=seq(0,20000,1)
points(PIP2,23.08467528*0.9996886969^PIP2,type='l',col='blue')
plot(c(5000,10000,15000),c(0.200,0.500,1.500),xlim=c(0,20000),ylim=c(0,2),xlab="PI45P2",ylab="Mean Open Time")
PIP2=seq(0,20000,1)
points(PIP2,0.0708439*1.0002^PIP2,type='l',col='blue')
par(mfrow=c(1,1))

ENaC=1
while(sum(ENaC)<tmax)
	{
	PIP2=out[round(sum(ENaC),0),7]
	ENaC=c(ENaC,rexp(1,1/(23.08467528*0.9996886969^PIP2)))	# duration of closed state
	PIP2=out[round(sum(ENaC),0),7]
	ENaC=c(ENaC,rexp(1,1/(0.0708439*1.0002^PIP2)))	# duration of open state
	}

ENaC
head(ENaC)
ENaCt=vector()
for (i in 1:length(ENaC))
	{
	ENaCt[i]=sum(ENaC[1:i])
	}

windows()
par(mfrow=c(5,1))
plot(ENaCt,rep(c(1,0),length(ENaC))[1:length(ENaC)],type='s',xlim=c(30,50),main="Basal PI45P2 ~ 10000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(50,50),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(ENaCt,rep(c(1,0),length(ENaC))[1:length(ENaC)],type='s',xlim=c(10,130),main="Low PI45P2 ~ 5000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(130,130),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(ENaCt,rep(c(1,0),length(ENaC))[1:length(ENaC)],type='s',xlim=c(280,300),main="High PI45P2 ~ 15000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(300,300),y=c(0,1),c('O','C'),col=c('blue','blue'))
par(mfrow=c(1,1))

windows()
par(mfrow=c(3,1))
plot(ENaCt,rep(c(1,0),length(ENaC))[1:length(ENaC)],type='s',col='black',xlim=c(1,300),main="Exponential",xlab="Time(s)",ylab="ENaC")
text(x=c(300,300),y=c(0,1),c('O','C'),col=c('blue','blue'))





### third try

# Mean close and open time of openning
par(mfrow=c(2,1))
plot(c(5000,10000,15000),c(4.500,1.200,0.200),xlim=c(0,20000),ylim=c(0,5),xlab="PI45P2",ylab="Mean Close Time")
PIP2=seq(0,20000,1)
points(PIP2,23.08467528*0.9996886969^PIP2,type='l',col='blue')
plot(c(5000,10000,15000),c(0.200,0.500,1.500),xlim=c(0,20000),ylim=c(0,2),xlab="PI45P2",ylab="Mean Open Time")
PIP2=seq(0,20000,1)
points(PIP2,0.0708439*1.0002^PIP2,type='l',col='blue')
par(mfrow=c(1,1))

membranestate = c('Basal','ATP','Suramin','U73122')
PIP2levels = c(10000,5000,15000,15000)
closemean = c(1.249,4.643,.174,.363)
closeSD = c(0.090,0.463,.023,.068)
openmean = c(.540,.129,1.349,1.544)
openSD = c(.045,0.019,.182,.289)
cbind(membranestate,PIP2levels,closemean,closeSD,openmean,openSD)

plot(c(closemean,openmean),c(closeSD,openSD),col=c(rep('red',4),rep('green',4)))
SDreg = lm(c(closeSD,openSD)~c(closemean,openmean))
b=SDreg$coef[1]
m=SDreg$coef[2]
summary(SDreg)
points(c(closemean,openmean),SDreg$fitted.values,type='b')
pwr = function(x) {.1199022558*x^.9129748547}
points(c(closemean,openmean),pwr(c(closemean,openmean)),type='p',col='cyan')
points(seq(0,5,0.1),pwr(seq(0,5,0.1)),type='l',col='blue')
# seems that the linear model is only a little bit worst that the power model, 
# and R2 is almost the same. So I am going with the linear model



ENaC=1
while(sum(ENaC)<tmax)
	{
	PIP2=out[round(sum(ENaC),0),7]
	ENaC=c(ENaC,rnorm(1,mean=(23.08467528*0.9996886969^PIP2),sd=(m*(23.08467528*0.9996886969^PIP2)+b)))	# duration of closed state
	PIP2=out[round(sum(ENaC),0),7]
	ENaC=c(ENaC,rnorm(1,mean=(0.0708439*1.0002^PIP2),sd=(m*(0.0708439*1.0002^PIP2)+b)))	# duration of open state
	}

ENaC
head(ENaC)
ENaCt=vector()
for (i in 1:length(ENaC))
	{
	ENaCt[i]=sum(ENaC[1:i])
	}

windows()
par(mfrow=c(5,1))
plot(ENaCt,rep(c(1,0),length(ENaC))[1:length(ENaC)],type='s',xlim=c(30,50),main="Basal PI45P2 ~ 10000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(50,50),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(ENaCt,rep(c(1,0),length(ENaC))[1:length(ENaC)],type='s',xlim=c(10,130),main="Low PI45P2 ~ 5000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(130,130),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(ENaCt,rep(c(1,0),length(ENaC))[1:length(ENaC)],type='s',xlim=c(280,300),main="High PI45P2 ~ 15000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(300,300),y=c(0,1),c('O','C'),col=c('blue','blue'))
par(mfrow=c(1,1))

windows()
par(mfrow=c(3,1))
plot(ENaCt,rep(c(1,0),length(ENaC))[1:length(ENaC)],type='s',col='black',xlim=c(1,300),main="Exponential",xlab="Time(s)",ylab="ENaC")
text(x=c(300,300),y=c(0,1),c('O','C'),col=c('blue','blue'))





### fourth try

# Mean close and open time of openning
par(mfrow=c(2,1))
plot(c(5000,10000,15000),c(4.500,1.200,0.200),xlim=c(0,20000),ylim=c(0,5),xlab="PI45P2",ylab="Mean Close Time")
PIP2=seq(0,20000,1)
points(PIP2,23.08467528*0.9996886969^PIP2,type='l',col='blue')
plot(c(5000,10000,15000),c(0.200,0.500,1.500),xlim=c(0,20000),ylim=c(0,2),xlab="PI45P2",ylab="Mean Open Time")
PIP2=seq(0,20000,1)
points(PIP2,0.0708439*1.0002^PIP2,type='l',col='blue')
par(mfrow=c(1,1))



ENaC=1
channelstate=0
while(sum(ENaC)<tmax)
	{
	PIP2=out[round(sum(ENaC),0),7]
	channelstate=c(channelstate,rbinom(1,1,1-(0.9962264151/(1+121.6307278*exp(-5.2159335E-4*PIP2)))))
	if (tail(channelstate,1)==0)
		{ENaC=c(ENaC,rexp(1,1/(23.08467528*0.9996886969^PIP2)))} else	# duration of closed state
		{ENaC=c(ENaC,rexp(1,1/(0.0708439*1.0002^PIP2)))	}			# duration of open state
	}


ENaC
head(ENaC)
ENaCt=vector()
for (i in 1:length(ENaC))
	{
	ENaCt[i]=sum(ENaC[1:i])
	}

length(channelstate)
length(ENaC)
length(ENaCt)
cbind(channelstate,ENaC,ENaCt)

windows()
par(mfrow=c(5,1))
plot(ENaCt,channelstate,type='s',xlim=c(30,50),main="Basal PI45P2 ~ 10000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(50,50),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(ENaCt,channelstate,type='s',xlim=c(10,130),main="Low PI45P2 ~ 5000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(130,130),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(ENaCt,channelstate,type='s',xlim=c(280,300),main="High PI45P2 ~ 15000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(300,300),y=c(0,1),c('O','C'),col=c('blue','blue'))
par(mfrow=c(1,1))

windows()
par(mfrow=c(3,1))
plot(ENaCt,channelstate,type='s',col='black',xlim=c(1,300),main="Exponential",xlab="Time(s)",ylab="ENaC")
text(x=c(300,300),y=c(0,1),c('O','C'),col=c('blue','blue'))





### fifth try

# Mean close and open time of openning
par(mfrow=c(2,1))
plot(c(5000,10000,15000),c(4.500,1.200,0.200),xlim=c(0,20000),ylim=c(0,5),xlab="PI45P2",ylab="Mean Close Time")
PIP2=seq(0,20000,1)
points(PIP2,23.08467528*0.9996886969^PIP2,type='l',col='blue')
plot(c(5000,10000,15000),c(0.200,0.500,1.500),xlim=c(0,20000),ylim=c(0,2),xlab="PI45P2",ylab="Mean Open Time")
PIP2=seq(0,20000,1)
points(PIP2,0.0708439*1.0002^PIP2,type='l',col='blue')
par(mfrow=c(1,1))



ENaC=1
channelstate=0
while(sum(ENaC)<tmax)
	{
	PIP2=out[round(sum(ENaC),0),7]
	channelstate=c(channelstate,rbinom(1,1,1-(0.9962264151/(1+121.6307278*exp(-5.2159335E-4*PIP2)))))
	if (tail(channelstate,1)==0)
		{ENaC=c(ENaC,0.01)} else	# duration of closed state
		{ENaC=c(ENaC,rexp(1,1/(0.0708439*1.0002^PIP2)))	}			# duration of open state
	}


ENaC
head(ENaC)
ENaCt=vector()
for (i in 1:length(ENaC))
	{
	ENaCt[i]=sum(ENaC[1:i])
	}

length(channelstate)
length(ENaC)
length(ENaCt)
cbind(channelstate,ENaC,ENaCt)

windows()
par(mfrow=c(5,1))
plot(ENaCt,channelstate,type='s',xlim=c(30,50),main="Basal PI45P2 ~ 10000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(50,50),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(ENaCt,channelstate,type='s',xlim=c(10,130),main="Low PI45P2 ~ 5000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(130,130),y=c(0,1),c('O','C'),col=c('blue','blue'))
plot(ENaCt,channelstate,type='s',xlim=c(280,300),main="High PI45P2 ~ 15000",xlab="Time(s)",ylab="ENaC open/close")
text(x=c(300,300),y=c(0,1),c('O','C'),col=c('blue','blue'))
par(mfrow=c(1,1))

windows()
par(mfrow=c(3,1))
plot(ENaCt,channelstate,type='s',col='black',xlim=c(1,300),main="Exponential",xlab="Time(s)",ylab="ENaC")
text(x=c(300,300),y=c(0,1),c('O','C'),col=c('blue','blue'))




